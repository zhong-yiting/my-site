import { useState } from 'react';

export default function Home() {
  const [projects] = useState([
    {
      id: 1,
      name: '数据清洗',
      description: '学习数据清洗的基本方法，处理缺失值、异常值、重复值等数据质量问题。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Data%20cleaning%20process%20with%20missing%20values%20handling%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['Python', 'pandas', '数据预处理']
    },
    {
      id: 2,
      name: '购物篮分析',
      description: '使用关联规则挖掘技术分析购物篮数据，发现商品间的关联关系。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Shopping%20basket%20analysis%20with%20association%20rules%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['关联规则', 'Apriori', '市场篮分析']
    },
    {
      id: 3,
      name: '客户聚类分析',
      description: '使用聚类算法对客户进行分群，识别不同客户群体的特征和行为模式。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Customer%20clustering%20analysis%20with%20K-means%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['K-means', '客户分群', '聚类分析']
    },
    {
      id: 4,
      name: '数据可视化',
      description: '学习使用Python可视化库创建各种图表，有效展示数据分析结果。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Data%20visualization%20with%20charts%20and%20graphs%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['Matplotlib', 'Seaborn', '数据展示']
    },
    {
      id: 5,
      name: '分组聚类分析',
      description: '深入学习聚类分析方法，包括层次聚类、密度聚类等多种聚类技术。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Hierarchical%20clustering%20dendrogram%20visualization%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['层次聚类', 'DBSCAN', '聚类评估']
    },
    {
      id: 6,
      name: 'AB测试',
      description: '学习AB测试的设计与分析方法，评估不同方案的效果差异。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=AB%20testing%20experiment%20comparison%20dashboard%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['假设检验', '统计分析', '实验设计']
    },
    {
      id: 7,
      name: '店铺经营分析',
      description: '分析店铺经营数据，包括销售额、客流量、转化率等关键指标。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Store%20operation%20analysis%20dashboard%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['经营指标', '销售分析', 'KPI分析']
    },
    {
      id: 8,
      name: '消费者行为分析',
      description: '分析消费者购买行为数据，了解消费者偏好和购买决策过程。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Consumer%20behavior%20analysis%20with%20purchase%20patterns%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['行为分析', '用户画像', 'RFM模型']
    },
    {
      id: 9,
      name: '市场分析',
      description: '进行市场趋势分析、竞争分析，为市场决策提供数据支持。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Market%20analysis%20with%20trends%20and%20competition%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['市场趋势', '竞争分析', 'SWOT分析']
    },
    {
      id: 10,
      name: '时间序列分析',
      description: '学习时间序列数据的分析方法，进行趋势预测和季节性分析。',
      image: 'https://trae-api-cn.mchost.guru/api/ide/v1/text_to_image?prompt=Time%20series%20analysis%20with%20forecasting%2C%20modern%20design&image_size=landscape_16_9',
      tags: ['时间序列', 'ARIMA', '预测模型']
    }
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-blue-100">
      {/* 导航栏 */}
      <nav className="bg-white shadow-md fixed w-full z-10">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="text-xl font-bold text-blue-600">钟依廷的个人页面</div>
          <div className="flex space-x-4">
            <a href="#home" className="text-blue-600 hover:text-blue-800">首页</a>
            <a href="#projects" className="text-blue-600 hover:text-blue-800">训练项目</a>
            <a href="#guestbook" className="text-blue-600 hover:text-blue-800">留言板</a>
          </div>
        </div>
      </nav>

      {/* 个人信息部分 */}
      <section id="home" className="pt-24 pb-16 px-4 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto max-w-4xl">
          <div className="flex flex-col md:flex-row items-center justify-center">
            <div className="mb-8 md:mb-0">
              <div className="w-48 h-48 rounded-full bg-white p-2 shadow-lg">
                <div className="w-full h-full rounded-full bg-blue-100 flex items-center justify-center">
                  <span className="text-4xl font-bold text-blue-600">钟</span>
                </div>
              </div>
            </div>
            <div className="md:ml-8 text-center md:text-left">
              <h1 className="text-3xl md:text-4xl font-bold mb-2">钟依廷</h1>
              <p className="text-xl mb-4">广东科学技术职业学院</p>
              <p className="text-lg mb-6">商学院 · 商务数据分析与应用专业</p>
              <div className="flex flex-wrap gap-2 mb-6">
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">Python</span>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">数据可视化</span>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">数据库应用</span>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">数据分析</span>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">数据采集</span>
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">供应链分析</span>
              </div>
              <p className="text-white mb-4">
                具有扎实的数据分析基础，熟练掌握Python编程、数据可视化和数据库应用技能，
                具备较强的问题解决能力和团队协作精神，
                目标成为一名优秀的商务数据分析专员。
              </p>
              <div className="flex space-x-4">
                <a href="#projects" className="bg-white text-blue-800 px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                  训练项目
                </a>
                <a href="#guestbook" className="bg-transparent border-2 border-white text-white px-4 py-2 rounded-lg font-medium hover:bg-white hover:text-blue-800 transition-colors">
                  留言板
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 留言板部分 */}
      <section id="guestbook" className="py-16 px-4 bg-gradient-to-b from-blue-50 to-blue-100">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12 text-blue-800">留言板</h2>
          
          {/* 留言表单 */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 className="text-xl font-bold mb-4 text-blue-800">留下您的留言</h3>
            <form onSubmit={(e) => e.preventDefault()} className="space-y-4">
              <div>
                <label className="block text-gray-700 mb-2">姓名</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="请输入您的姓名"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">邮箱</label>
                <input 
                  type="email" 
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="请输入您的邮箱"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">留言内容</label>
                <textarea 
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  rows={4}
                  placeholder="请输入您的留言内容"
                ></textarea>
              </div>
              <button 
                type="submit"
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                提交留言
              </button>
            </form>
          </div>
          
          {/* 留言列表 */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold mb-4 text-blue-800">最新留言</h3>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                  <span className="text-xl font-bold text-blue-600">张</span>
                </div>
                <div>
                  <h4 className="font-semibold text-blue-800">张老师</h4>
                  <p className="text-sm text-gray-500">2026-04-13</p>
                </div>
              </div>
              <p className="text-gray-600">课程内容很丰富，项目经验展示得很好，继续加油！</p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                  <span className="text-xl font-bold text-blue-600">李</span>
                </div>
                <div>
                  <h4 className="font-semibold text-blue-800">李同学</h4>
                  <p className="text-sm text-gray-500">2026-04-12</p>
                </div>
              </div>
              <p className="text-gray-600">页面设计得很好看，项目经验展示得很清晰！</p>
            </div>
          </div>
        </div>
      </section>

      {/* 训练项目部分 */}
      <section id="projects" className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-4 text-blue-800">商务数据分析训练项目</h2>
          <p className="text-center text-gray-600 mb-12">包含教学教程讲解和实训环节，全面提升数据分析实战能力</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <div key={project.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.name} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 text-blue-800">{project.name}</h3>
                  <p className="text-gray-600 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, index) => (
                      <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">{tag}</span>
                    ))}
                  </div>
                  <div className="flex space-x-2">
                    <a href={`/project/${project.id}`} className="flex-1 text-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                      教学教程
                    </a>
                    <a href={`/practice/${project.id}`} className="flex-1 text-center bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm">
                      实训练习
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 页脚 */}
      <footer className="bg-blue-800 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <p>© 2026 钟依廷的个人页面</p>
        </div>
      </footer>
    </div>
  );
}